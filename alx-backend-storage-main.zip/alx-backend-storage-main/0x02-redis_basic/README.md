# Redis basic

## Learning Objectives

* Learn how to use redis for basic operations
* Learn how to use redis as a simple cache
